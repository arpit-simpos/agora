import React, { Component } from 'react';

export class Home extends Component {
  static displayName = Home.name;

  render () {
    return (
      <div>
            <b> Welcome to Agora class room </b>
            <br />
     
                <h2> by Simpos </h2>
        </div>
    );
  }
}
